"""
Common modules for MOOD.
"""
