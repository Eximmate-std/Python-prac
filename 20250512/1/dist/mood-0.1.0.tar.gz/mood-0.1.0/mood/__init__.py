"""
MOOD MUD Game package.
"""
